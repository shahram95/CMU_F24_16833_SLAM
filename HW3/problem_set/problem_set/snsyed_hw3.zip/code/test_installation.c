#include <stdio.h>
   #include <suitesparse/cs.h>

   int main() {
       printf("SuiteSparse version: %d\n", SUITESPARSE_VERSION);
       return 0;
   }
